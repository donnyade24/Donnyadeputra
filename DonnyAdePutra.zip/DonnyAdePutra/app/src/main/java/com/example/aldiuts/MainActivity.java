package com.example.aldiuts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import static com.example.aldiuts.R.*;

public class MainActivity extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    private BottomNavigationView.OnNavigationItemReselectedListener navigation = new BottomNavigationView.OnNavigationItemReselectedListener() {
        @Override
        public void onNavigationItemReselected(MenuItem item) {
            Fragment f = null;
            switch (item.getItemId()){
                case R.id.menu_telp:
                f = new Fragmen_Telp();
                break;

                case R.id.menu_web:
                f = new Fragmen_Web();
                break;

                case R.id.menu_map:
                f = new Fragmen_Map();
                break;

                case R.id.menu_mail:
                f = new Fragment_Mail();
                break;


            }
            getSupportFragmentManager().beginTransaction().replace(id.cotainer_fragmen,f).commit();
            return;

        }
    };






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_main);
        bottomNavigationView = findViewById(id.bottom_navigation_menu);
        bottomNavigationView.setOnNavigationItemReselectedListener(navigation);
    }
}